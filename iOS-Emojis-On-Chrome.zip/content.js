// URL to the emoji data JSON file
const emojiDataUrl = "https://cdn.jsdelivr.net/npm/emoji-datasource-apple@latest/emoji.json";

// Function to fetch emoji data once and store it globally
let emojiMapping = new Map();
async function fetchEmojiData() {
  if (emojiMapping.size > 0) return; // Prevent duplicate fetches
  const response = await fetch(emojiDataUrl);
  const emojiData = await response.json();

  emojiData.forEach((emoji) => {
    const unicode = emoji.unified.toLowerCase();
    const emojiUrl = `https://cdn.jsdelivr.net/npm/emoji-datasource-apple/img/apple/64/${unicode}.png`;
    emojiMapping.set(emoji.unified, emojiUrl);

    if (emoji.skin_variations) {
      Object.values(emoji.skin_variations).forEach((variation) => {
        const variationUnicode = variation.unified.toLowerCase();
        const variationUrl = `https://cdn.jsdelivr.net/npm/emoji-datasource-apple/img/apple/64/${variationUnicode}.png`;
        emojiMapping.set(variation.unified, variationUrl);
      });
    }
  });
}

// Function to replace emojis in a single text node
function replaceEmojisInTextNode(node) {
  if (!node.nodeValue) return;

  const emojiRegex = /[\u{1F300}-\u{1F5FF}\u{1F600}-\u{1F64F}\u{1F680}-\u{1F6FF}\u{2600}-\u{26FF}\u{2700}-\u{27BF}]/gu;
  const newText = node.nodeValue.replace(emojiRegex, (emoji) => {
    const codePoints = Array.from(emoji).map((char) => char.codePointAt(0).toString(16).toUpperCase()).join("-");
    const emojiUrl = emojiMapping.get(codePoints);
    return emojiUrl ? `<img src="${emojiUrl}" alt="${emoji}" style="height: 1.2em; vertical-align: middle; max-width: 100%;">` : emoji;
  });

  if (newText !== node.nodeValue) {
    const span = document.createElement("span");
    span.innerHTML = newText;
    node.replaceWith(span);
  }
}

// Debounced function to replace emojis in the DOM
let isProcessing = false;
function debouncedReplaceEmojis() {
  if (isProcessing) return;
  isProcessing = true;

  requestAnimationFrame(() => {
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    let node;
    while ((node = walker.nextNode())) {
      replaceEmojisInTextNode(node);
    }
    isProcessing = false;
  });
}

// Optimized MutationObserver
const observer = new MutationObserver((mutations) => {
  debouncedReplaceEmojis(); // Debounce to reduce CPU usage
});

observer.observe(document.body, { childList: true, subtree: true });

// Run the replacement when the page loads
fetchEmojiData().then(() => {
  debouncedReplaceEmojis();
});
