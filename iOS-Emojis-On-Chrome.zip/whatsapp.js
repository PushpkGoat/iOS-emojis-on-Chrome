(function () {
    // URL to the emoji data JSON file
    const emojiDataUrl = "https://cdn.jsdelivr.net/npm/emoji-datasource-apple@latest/emoji.json";
  
    // Function to fetch emoji data once and store it globally
    let emojiMapping = new Map();
    async function fetchEmojiData() {
      if (emojiMapping.size > 0) return; // Prevent duplicate fetches
      const response = await fetch(emojiDataUrl);
      const emojiData = await response.json();
  
      emojiData.forEach((emoji) => {
        const unicode = emoji.unified.toLowerCase();
        const emojiUrl = `https://cdn.jsdelivr.net/npm/emoji-datasource-apple/img/apple/64/${unicode}.png`;
        emojiMapping.set(emoji.unified, emojiUrl);
  
        if (emoji.skin_variations) {
          Object.values(emoji.skin_variations).forEach((variation) => {
            const variationUnicode = variation.unified.toLowerCase();
            const variationUrl = `https://cdn.jsdelivr.net/npm/emoji-datasource-apple/img/apple/64/${variationUnicode}.png`;
            emojiMapping.set(variation.unified, variationUrl);
          });
        }
      });
    }
  
    // Function to replace WhatsApp Web emojis
    function replaceWhatsAppEmojis() {
      const emojiImages = document.querySelectorAll('img[alt][draggable="false"][class*="selectable-text"]');
      emojiImages.forEach((img) => {
        const altText = img.getAttribute("alt");
        const codePoints = Array.from(altText).map((char) => char.codePointAt(0).toString(16).toUpperCase()).join("-");
        const emojiUrl = emojiMapping.get(codePoints);
        if (emojiUrl) {
          // Create a new image element to replace the existing one
          const newImg = document.createElement("img");
          newImg.src = emojiUrl;
          newImg.alt = altText;
          newImg.style.verticalAlign = "middle";
          newImg.style.objectFit = "contain"; // Prevent blurriness
          newImg.style.display = "inline-block"; // Fix alignment with text
  
          // Replace the old emoji with the new one
          img.replaceWith(newImg);
  
          // Check if the emoji is used alone or with text
          const parent = newImg.parentElement;
          if (parent.childNodes.length === 1 && parent.textContent.trim() === altText) {
            // Single emoji: 64x64px
            newImg.style.height = "64px";
            newImg.style.width = "64px";
          } else {
            // Emoji with text: 20x20px
            newImg.style.height = "20px";
            newImg.style.width = "20px";
          }
        }
      });
    }
  
    // Debounced function to replace emojis in WhatsApp Web
    let isProcessing = false;
    function debouncedReplaceWhatsAppEmojis() {
      if (isProcessing) return;
      isProcessing = true;
  
      requestAnimationFrame(() => {
        replaceWhatsAppEmojis();
        isProcessing = false;
      });
    }
  
    // Optimized MutationObserver
    const observer = new MutationObserver((mutations) => {
      mutations.forEach((mutation) => {
        if (mutation.type === "childList") {
          // Check if new nodes are added
          mutation.addedNodes.forEach((node) => {
            if (node.nodeType === Node.ELEMENT_NODE) {
              // Replace emojis in the new nodes
              const emojiImages = node.querySelectorAll('img[alt][draggable="false"][class*="selectable-text"]');
              if (emojiImages.length > 0) {
                debouncedReplaceWhatsAppEmojis();
              }
            }
          });
        }
      });
    });
  
    observer.observe(document.body, { childList: true, subtree: true });
  
    // Run the replacement when the page loads
    fetchEmojiData().then(() => {
      debouncedReplaceWhatsAppEmojis();
  
      // Periodically check for missed emojis (e.g., in previous chats)
      setInterval(() => {
        debouncedReplaceWhatsAppEmojis();
      }, 2000); // Check every 2 seconds
    });
  })();