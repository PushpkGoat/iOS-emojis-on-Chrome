// Background script (optional)
chrome.runtime.onInstalled.addListener(() => {
    console.log("iOS Emoji Replacer extension installed.");
  });